#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

int main() {
    setup();

    printf("%p\n", &fgets);
    printf("Enter address, size and data: ");
    unsigned long addr, size;
    scanf("%zu %zu ", &addr, &size);
    fgets((void*)addr, size, stdin);
    fork();
}