// gcc vuln.c -o vuln -fstack-protector -Wl,-z,relro,-z,now
#include <stdlib.h>
#include <stdio.h>

int main() {
	// libc leak
    printf("printf: %p\n", &printf);

	// controlled data
    void *ptr = malloc(0x400);
    printf("ptr: %p\n", ptr);
    fgets(ptr, 0x400, stdin);

	// function call primitive with controlled argument
    void (*func)(void*);
    scanf("%zu", (unsigned long*)&func);
    getchar();

    func(ptr);
}
